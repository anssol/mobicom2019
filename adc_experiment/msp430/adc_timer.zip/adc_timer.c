#include <stdio.h>
#include <msp430.h> 

unsigned short adc_result = 0;
static unsigned int cnt;
unsigned int i;

// Define array for storing ADC samples
static const bufferLen = 100;
static short adcVals[bufferLen];

void set_pins(void) {
        // GPIO Setup
        P1SEL1 |= BIT3;                             // P1.3 input per ADC
        P1SEL0 |= BIT3;                             // P1.3 input per ADC
        P1DIR |= BIT3;                              // P1.3 input per ADC
        P1DIR |= BIT5;                              // For toggling
}


void init_timers() {
    TA0CCTL0 = CCIE;                                // Enable interrupt

    /* Change the count here (or the clock source)
     * to determine the sample frequency.
     */
    TA0CCR0 = 1700;                                   // PWM Period

    TA0CCTL1 = OUTMOD_3;                            // TACCR1 set/reset
    TA0CCR1 = 2;                                    // TACCR1 PWM Duty Cycle
    TA0CTL = TASSEL_1 + MC_1;                       // ACLK, up mode
}

void configure_adc() {

    while(REFCTL0 & REFGENBUSY);                    // If ref generator busy, WAIT
    REFCTL0 |= REFVSEL_1 + REFON;                   // Select internal ref = 2V
                                                    // Internal Reference ON
                                                    // Used for various analog peripherals.
                                                    // Output voltage of P1.3

    // Configure ADC
    ADC12CTL0 &= ~ADC12ENC;                         // pre-disable adc12 conversion
    ADC12CTL0 |= ADC12SHT0_2;                       // 16 cycles ADC12CLK

    ADC12CTL1 |= ADC12SSEL_3;                       // clc source: SMCLK
    ADC12CTL1 |= ADC12SHP;                          // pulse sample mode selected
    ADC12IER0 |= ADC12IE0;                          // Enable ADC conv complete interrupt
    ADC12MCTL0 |= ADC12VRSEL_1 + ADC12INCH_3;       // input A0, VREF+ = vref, VREF- = VSS
                                                    // ADC12VRSEL_x defines the AD voltage window

    while(!(REFCTL0 & REFGENRDY));                  // Wait for reference generator to settle

    ADC12CTL2 |= ADC12RES_2;                        //  12 bit resolution
                                                    // ADC12RES_x defines the conversion result resolution.

    ADC12CTL0 |= ADC12ON;                           // Enable ADC12_B. This can only be modified if ADC12ENC = 0.

    ADC12CTL0 |= ADC12ENC + ADC12SC;                // Start the conversion

}

int main(void)
{
	WDTCTL = WDTPW | WDTHOLD;	                    // stop Watchdog timer

    PM5CTL0 &= ~LOCKLPM5;                           // Disable the GPIO power-on default high-impedance mode to activate
                                                    // previously configured port settings

    // Initialize
    set_pins();
    configure_adc();
    init_timers();

    cnt = 0;
	__bis_SR_register(LPM3_bits + GIE);             // Enter LPM3, enable interrupts
}

// ADC12 interrupt service routine
#pragma vector=ADC12_VECTOR
__interrupt void ADC12_ISR(void)
{
  while (ADC12CTL1 & ADC12BUSY) {}                  // Wait for ADC conversion to finish

  adcVals[cnt++] = ADC12MEM0;                       // Store the ADC samples in array
  if (cnt == bufferLen) {                           // Print the contents of array when it is full
      for (i = 0; i < bufferLen; i++) {
          printf("%d\n", adcVals[i]);
      }
      printf("\n");
      cnt = 0;
  }

  // WARNING, PRINTING IS A SLOW OPERATION
  //adc_result = ADC12MEM0;                           // Store the ADC samples
  //printf("%d\n", adc_result);
}

// Timer A0 interrupt service routine
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A(void)
{
    ADC12CTL0 |= ADC12ENC | ADC12SC;

    // Toggle pin to debug sample rate
    // Connect analyzer to P1.5 to check
    P1OUT ^= BIT5;
}
